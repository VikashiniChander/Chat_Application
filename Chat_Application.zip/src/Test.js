function Test() {
  return (

<svg width="11" height="20" viewBox="0 0 11 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M10 19L1 10L10 1" stroke="#A5AAAE" stroke-width="2" stroke-linejoin="round"/>
</svg>



    
    
  );

}

export default Test;

{/* <svg width="20" height="11" viewBox="0 0 20 11" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M1 10L10 1L19 10" stroke="#324552" stroke-width="2" stroke-linejoin="round"/>
</svg>
     */}


    //  <svg width="11" height="20" viewBox="0 0 11 20" fill="none" xmlns="http://www.w3.org/2000/svg">
    //  <path d="M1 19L10 10L1 1" stroke="#A5AAAE" stroke-width="2" stroke-linejoin="round"/>
    //  </svg>
     
         
