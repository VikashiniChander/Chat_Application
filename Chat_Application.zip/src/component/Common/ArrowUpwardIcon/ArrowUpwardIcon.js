function ArrowUpwardIcon() {
    return (
   
<svg width="20" height="11" viewBox="0 0 20 11" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M1 10L10 1L19 10" stroke="#324552" stroke-width="2" stroke-linejoin="round"/>
</svg>
         );
  
  }
  
  export default ArrowUpwardIcon;
  